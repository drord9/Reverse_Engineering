#include <windows.h>
#include <fstream>
#include <iostream>

using std::endl;
std::ofstream log_file("log.txt");

int i = 1;
int ret_add = 0;    // return address

__declspec(naked) void HOOK_NAME()
{
    __asm {
            mov eax, [ebp + 4];
            mov ret_add, eax;

            mov eax, i
            add [ebp + 8], eax
            add i, 1
    }

    //log_file << i++ << ": " << ret_add <<endl;

    switch (ret_add)
    {
    case 0x401541:
        __asm {
            mov     eax, [ebp + 8]
            xor eax, 11h
            mov[ebp - 4], eax
            mov     ecx, [ebp - 8]
            mov     edx, 66666667h
            mov     eax, ecx
            imul    edx
            mov     eax, edx
            sar     eax, 1
            mov     ebx, ecx
            sar     ebx, 1Fh
            sub     eax, ebx
            mov     edx, eax
            mov     eax, edx
            shl     eax, 2
            add     eax, edx
            sub     ecx, eax
            mov     edx, ecx
            mov[ebp - 8], edx
        }
        break;

    case 0x40157C:
        __asm {
            mov     eax, [ebp + 8]
            sar     eax, 1
            movzx   edx, al
            mov[ebp - 4], edx
            mov     ecx, [ebp - 8]
            mov     edx, 2AAAAAABh
            mov     eax, ecx
            imul    edx
            mov     eax, ecx
            sar     eax, 1Fh
            sub     edx, eax
            mov     eax, edx
            add     eax, eax
            add     eax, edx
            add     eax, eax
            sub     ecx, eax
            mov     edx, ecx
            mov[ebp - 8], edx
        }
        break;

    case 0x4015B9:
        __asm {
            mov     eax, [ebp + 8]
            mov[ebp - 4], eax
            add[ebp - 4], 3
            mov     ecx, [ebp - 8]
            mov     edx, 92492493h
            mov     eax, ecx
            imul    edx
            lea     eax, [edx + ecx]
            sar     eax, 2
            mov     ebx, ecx
            sar     ebx, 1Fh
            sub     eax, ebx
            mov     edx, eax
            mov     eax, edx
            shl     eax, 3
            sub     eax, edx
            sub     ecx, eax
            mov     edx, ecx
            mov[ebp - 8], edx
        }
        break;
    default:
        log_file << "not gooood !!!" << endl;
        exit(1);
    }

    __asm {
        ; do something here

        ; restore the commands overriden
        mov     eax, [ebp - 4]
        leave
        retn
    }
}

void setHook()
{

    HMODULE h = GetModuleHandle(NULL);
    CHAR JmpOpcode[7] = "\xE9\x90\x90\x90\x90\x90";
    DWORD lpProtect = 0;
    LPVOID JumpTo;

    if (h == NULL)
    {
        log_file << "couldnt get handle" << endl;
        return;
    }
    
    // get the hook point address ( module - imageBase + offset)
    char* f = (char*)h - 0x00400000 + 0x00401508;
    if (f[0] != '\x8B' || f[1] != '\x45' || f[2] != '\xFC')
    {
        log_file << "couldnt get hook poit" << endl;
        return;
    }

    int len_override = 5; // nubmer of bytes to override, changes from function to function
    
    log_file << "setting hook" << endl;
    // calculate relative jump to HOOK_NAME from f, add 5 cause its from eip after the execution
    JumpTo = (LPVOID)((char *)&HOOK_NAME - ((char *)f + 5));
    memcpy(JmpOpcode + 1, &JumpTo, 0x4); // write the jump
    VirtualProtect((char *)f, len_override, PAGE_EXECUTE_READWRITE, &lpProtect);
    memcpy((char *)f, &JmpOpcode, len_override);
    VirtualProtect((char *)f, len_override, PAGE_EXECUTE_READ, &lpProtect);
}

BOOL APIENTRY DllMain(HMODULE hModule,
                      DWORD ul_reason_for_call,
                      LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        setHook();
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}
